Follow these steps to compile:

1. Type "make" without the quotes.

2. Type "./color" without the quotes.  

3. Enjoy!